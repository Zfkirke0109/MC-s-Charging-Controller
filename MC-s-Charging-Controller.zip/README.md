# MC's Charging Controller (mcc)
# mcc README
# versionCode=2017122003
# MCMotheEffin' @ XDA Developers
